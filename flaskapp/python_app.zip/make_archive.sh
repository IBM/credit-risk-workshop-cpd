#! /bin/sh

git archive --format=zip --output=python_app.zip HEAD .
